enum RoleEnum {
  ADMIN = 'ADMIN',
  SUPERADMIN = 'SUPERADMIN',
}

export default RoleEnum;
