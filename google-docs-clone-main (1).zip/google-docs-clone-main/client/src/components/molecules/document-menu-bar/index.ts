export { default } from './document-menu-bar';
