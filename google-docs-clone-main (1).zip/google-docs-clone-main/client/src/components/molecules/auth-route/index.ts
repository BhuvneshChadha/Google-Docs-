export { default } from './auth-route';
