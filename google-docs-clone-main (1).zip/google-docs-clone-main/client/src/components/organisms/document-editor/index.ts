export { default } from './document-editor';
