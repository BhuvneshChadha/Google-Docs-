export { default } from './document-menu-button';
