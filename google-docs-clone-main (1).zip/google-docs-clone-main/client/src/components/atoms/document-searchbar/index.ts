export { default } from './document-searchbar';
