export { default } from './spinner';
