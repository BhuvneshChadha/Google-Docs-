export { default } from './document-card';
