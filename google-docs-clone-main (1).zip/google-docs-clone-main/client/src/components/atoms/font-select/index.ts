export const FONTS = ['Inter', 'Roboto', 'Open Sans'];

export { default } from './font-select';
