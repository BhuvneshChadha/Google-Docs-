interface DropdownProps {
  button: JSX.Element;
  menuItems: string[];
}

const Dropdown = () => {
  return <></>;
};

export default Dropdown;
