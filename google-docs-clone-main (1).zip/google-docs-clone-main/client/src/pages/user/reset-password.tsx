const ResetPassword = () => {
  return <></>;
};

export default ResetPassword;
