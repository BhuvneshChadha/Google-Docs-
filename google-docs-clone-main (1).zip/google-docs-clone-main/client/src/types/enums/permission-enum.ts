enum PermissionEnum {
  VIEW = 'VIEW',
  EDIT = 'EDIT',
}

export default PermissionEnum;
