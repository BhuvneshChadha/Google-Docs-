enum ThemeEnum {
  LIGHT,
  DARK,
}

export default ThemeEnum;
