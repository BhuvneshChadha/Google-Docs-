enum SocketEvent {
  SEND_CHANGES = 'send-changes',
  RECEIVE_CHANGES = 'receive-changes',
  CURRENT_USERS_UPDATE = 'current-users-update',
}

export default SocketEvent;
