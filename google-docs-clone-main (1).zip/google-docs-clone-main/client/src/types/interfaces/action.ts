interface ActionInterface {
  label: string;
  action: Function;
}

export default ActionInterface;
