interface Token {
  exp: number;
  id: number;
  email: string;
}

export default Token;
