interface InputProps {
  label?: string;
  placeholder?: string;
  errors?: Array<string>;
}

export default InputProps;
